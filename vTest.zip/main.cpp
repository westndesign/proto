#include <iostream>
#include <fstream>
#include <string>

#include "generated/addressbook.pb.h"

using namespace std;

int main(int argc, char* argv[]) {
	GOOGLE_PROTOBUF_VERIFY_VERSION;

	tutorial::Person Aperson;
	tutorial::Person Bperson;
	
	Aperson.set_name("frog");
	
	string str = "";
	Aperson.SerializeToString(&str);
	
	cout << str << endl;
	
	Bperson.ParseFromString(str);
	
	cout << Bperson.name() << endl;

	google::protobuf::ShutdownProtobufLibrary();

  return 0;
}
